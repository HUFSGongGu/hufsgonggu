const firstPassword = document.querySelector("#firstInput");
const secondPassword = document.querySelector("#secondInput");
const check = document.createElement("div");

function checkPassword() {
    if (firstPassword.value === secondPassword.value) {
    }
}
